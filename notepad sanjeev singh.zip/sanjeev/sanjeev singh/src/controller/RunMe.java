package controller;

import notepade_s_plus.NotepadSPlus;

public class RunMe {

	public static void main(String[] args) throws Exception {

		NotepadSPlus notepadSPlus=new NotepadSPlus();
		notepadSPlus.setVisible(true);
		notepadSPlus.setLocation(100, 150);
		
		
		
		
		
		
	}	
	

}
