package notepade_s_plus;

public interface MenuNames
{  
	  String FILE="File";  
	  String EDIT="Edit";  
	  String FORMAT="Format";  
	  String VIEW="View";  
	  String SPEAK="Speak";
	  String HELP="Help";  
	 
	   
	  String NEWFILE="New";  
	  String OPEN="Open...";  
	  String SAVE="Save";  
	  String SAVE_AS="Save As...";  
	  String PAGE_SETUP="Page Setup...";  
	  String PRINT="Print";  
	  String EXIT="Exit";  
	   
//	  String UNDO="Undo";  	 
//	  String REDO="Redo";  
	  String CUT="Cut";  
	  String COPY="Copy";  
	  String PASTE="Paste";  
	  String DELETE="Delete";  
	  String FIND="Find...";  
	  String REPLACE="Replace";  
	  String GO_TO="Go To...";  
	  String SELECT_ALL="Select All";  
	  String TIME_DATE="Time/Date";  
	   
	  String WORD_WRAP="Word Wrap";  
	  String FONT="Font...";  
	  String COLOR="Set Color";  
	  String FOREGROUND="Set Text color...";  
	  String BACKGROUND="Set Background color...";  
	   
	  String STATUS_BAR="Status Bar";  
	  
	  
	  String READER="Read";
	  
	  
	  String HELP_TOPIC="Help Topic";  
	  String ABOUT_NOTEPAD="About NotepadJavaSPlus";  
	   
	  String ABOUT_CREATOR="About Creator";  
	  String aboutNotepad="sanjeev";
	  String aboutCreator="sanjeev";
	 }  
	 
	 