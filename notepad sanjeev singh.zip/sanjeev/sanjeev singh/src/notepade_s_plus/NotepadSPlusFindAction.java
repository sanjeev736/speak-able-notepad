package notepade_s_plus;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.TextEvent;
import java.awt.event.TextListener;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;

public class NotepadSPlusFindAction extends JPanel implements ActionListener {
	
	JTextArea area;
	public int lastIndex;
	JLabel replaceLabel;

	TextField findTextField;
	
	TextField replaceTextField;

	JCheckBox matchCase;

	JRadioButton up, down;//X

	JButton findNext, replaceText, replaceAll, cancel;

	JPanel  findAndReplacePanel,textPanel,direction,buttonPanel,southPanel;//dir x
	 
	private JDialog dialog;
		

	
	/////////////////////////////////
	NotepadSPlus notepad;
	
	public NotepadSPlusFindAction(NotepadSPlus notepad) {
		
		this.notepad=notepad;
	}
	

	

	public void findDiaglog(JTextArea area)
	{
		this.area=area;
		findTextField=new TextField(50);

		replaceTextField =new TextField(50);
		 replaceLabel=new JLabel("Replace");
		JLabel find=new JLabel("Find");
		

		matchCase=new JCheckBox("Exact Match");
		up=new JRadioButton("Up");
		down=new JRadioButton("Down");
		down.setSelected(true);
		
		ButtonGroup group=new ButtonGroup();
		group.add(up);
		group.add(down);
		
		
		
		direction=new JPanel();
		Border etched=BorderFactory.createEtchedBorder();
		Border titled=BorderFactory.createTitledBorder(etched,"Direction");
		direction.setBorder(titled);
		direction.setLayout(new GridLayout(1,2));
		direction.add(up);
		direction.add(down);
		
		 
		southPanel=new JPanel();
		southPanel.setLayout(new GridLayout(1, 2));
		southPanel.add(matchCase);
		southPanel.add(direction);
		
		
		
		findNext=new JButton("Find");
		replaceText=new JButton("Replace");
		replaceAll=new JButton("Replace All");
		cancel=new JButton("Cancel");		
		
		findNext.setEnabled(false);			
		replaceText.setEnabled(false);
		replaceAll.setEnabled(false);

		
		
		findNext.setSize(50, 60);
		findAndReplacePanel=new JPanel();
		findAndReplacePanel.setLayout(new GridLayout(5, 1));
		findAndReplacePanel.add(findNext);
		findAndReplacePanel.add(new JLabel("  "));
		findAndReplacePanel.add(replaceText);
		findAndReplacePanel.add(new JLabel("  "));
	//	findAndReplacePanel.add(replaceAll);
		findAndReplacePanel.add(cancel);
		
		
		textPanel=new JPanel();
		textPanel.setLayout(new GridLayout(3, 2));
		textPanel.add(find);
		textPanel.add(findTextField);
		textPanel.add(replaceLabel);
		textPanel.add(replaceTextField);
		textPanel.add(new JLabel(" "));
//		textPanel.add(new JLabel(" "));
		textPanel.add(replaceAll);
		
		
		findNext.addActionListener(this);
		replaceText.addActionListener(this);
		replaceAll.addActionListener(this);
		cancel.addActionListener(this);
		
	
		findTextField.addFocusListener(new FocusAdapter() {
		@Override
		public void focusLost(FocusEvent fevt) {
			
			
			enableDisableButtons();
			
		}

		
			
		});
		findTextField.addTextListener(new TextListener() {
			
			@Override
			public void textValueChanged(TextEvent tevt) {
				
				enableDisableButtons();
			}
		});
		
		replaceTextField.addTextListener(new TextListener() {
			
			@Override
			public void textValueChanged(TextEvent tevt) {
				
				enableDisableButtons();
			}
		});
		
		
		
		
		
		
		setLayout(new BorderLayout());
		add(new JLabel("   "),BorderLayout.NORTH);
		add(textPanel,BorderLayout.CENTER);
		add(findAndReplacePanel,BorderLayout.EAST);
		add(southPanel,BorderLayout.SOUTH);
		setSize(200, 200);
		
	
	
	
	}

	
	private void enableDisableButtons() {


		if(findTextField.getText().length()==0)
		{
	
			findNext.setEnabled(false);			
			replaceText.setEnabled(false);
			replaceAll.setEnabled(false);
		
		}
		else
		{
			findNext.setEnabled(true);			
			
		}

		if(replaceTextField.getText().length()==0)
		{
			replaceText.setEnabled(false);
			replaceAll.setEnabled(false);
			
		}else {
			if(findTextField.getText().length()==0)
			{
				JOptionPane.showMessageDialog(this, "Fill Find Box First","warning",JOptionPane.OK_OPTION);
			return;
			}
		
		replaceText.setEnabled(!false);
		replaceAll.setEnabled(!false);
				}

	}

	@Override
	public void actionPerformed(ActionEvent act) {

		
		if(act.getSource()==findNext)
		{
		
			findNextWithSelection();
			
		}else if (act.getSource()==replaceText) {
			replaceText();
			
		}else if (act.getSource()==replaceAll) {
			JOptionPane.showMessageDialog(null,"Total replacements made= "+replaceAllText());

			
		}else if (act.getSource()==cancel) {
			
			dialog.setVisible(false);
		}
		
		
		
		
		
		
		
		
		
		

//		switch(act.getActionCommand())
//		{
//		case :
//			break;
//		case:
//			break;
//		case:
//			break;
//		case:
//			break;
//		case:
//			break;
//		}
		
	}


	private void findNextWithSelection() {
			int lastIndex=findNext();
			System.out.println("lastIndex="+lastIndex+"\nfind field="+findTextField.getText().length());
			String notFound="";
			if(lastIndex!=-1)
			{
		
				area.setSelectionStart(lastIndex);
				area.setSelectionEnd(lastIndex+findTextField.getText().length());;
				
			}
			else
			{
				JOptionPane.showConfirmDialog(this,"<html>can not find<br>"+findTextField.getText()+"</html>","Find",JOptionPane.OK_OPTION);
			}
			
	}


	private void replaceText() {
		if(area.getSelectionStart()==area.getSelectionEnd()) 
		{findNextWithSelection();return;}
String findText,searchedText;
findText=findTextField.getText();
searchedText=area.getSelectedText();
if((matchCase.isSelected() && findText.equals(searchedText))||(!matchCase.isSelected() && findText.equalsIgnoreCase(searchedText)))
{
	area.replaceSelection(replaceTextField.getText());

}
//System.out.println("matchCase.isSelected()="+matchCase.isSelected()+"\n&& findText.equals(searchedText)"+findText.equals(searchedText));
//System.out.println("&& findText.equalsIgnoreCase(searchedText)="+findText.equalsIgnoreCase(searchedText));

findNextWithSelection();
	}


	private int replaceAllText() {
		area.setCaretPosition(0);

		int replacedTexts=0,lastIndex=0;
		do
		{
			lastIndex=findNext();
			
			if(lastIndex==-1)
			{
				break;
			}
			findNextWithSelection();
			
			area.replaceSelection(replaceTextField.getText());
			replacedTexts++;

			//area.replaceRange(replaceTextField.getText(), lastIndex,lastIndex+findTextField.getText().length());//?
//			System.out.println("**************\n"+lastIndex+"\n"+findTextField.getText().length());
			
		}while(lastIndex!=-1);



		return replacedTexts;
	}
	
	private Integer findNext()
	{
		String text=area.getText();
		String fText=findTextField.getText();
		lastIndex=area.getCaretPosition();

//System.out.println("1="+lastIndex);		
		
		
		int selectionStart=area.getSelectionStart();
		int selectionEnd=area.getSelectionEnd();	
	//System.out.println("selestart="+selectionStart+"\nseleend="+selectionEnd);
		if(up.isSelected())
		{
			if(selectionStart!=selectionEnd)
			{
				lastIndex=selectionEnd-fText.length()-1;
				
			}
			if(matchCase.isSelected())
			{
				lastIndex=text.lastIndexOf(fText, lastIndex);				
			}else {
				lastIndex=text.toUpperCase().indexOf(fText, lastIndex);
			}

		//	System.out.println("up");
		}else
		{

//System.out.println("2="+lastIndex);		
			if(selectionStart!=selectionEnd)
			{
				lastIndex=selectionStart+1;

//System.out.println("3="+lastIndex);		
			}
			if(matchCase.isSelected())
			{
				lastIndex=text.indexOf(fText, lastIndex);				
			}else {
				lastIndex=text.toUpperCase().indexOf(fText.toUpperCase(), lastIndex);

//System.out.println("4="+lastIndex);		
			}
			
		}
		
		
//System.out.println("5="+lastIndex);		
		
		return lastIndex;
	
		
		
	}
	
	public void  showDialog(Component notepadFrame,boolean isFindFrame) {
			
		Frame findFrame=null;
		if(notepadFrame instanceof Frame)
		{

			findFrame=(Frame)notepadFrame;
			
		}else {
			findFrame=(Frame)SwingUtilities.getAncestorOfClass(Frame.class,notepadFrame);//?
		}
		
		
		
		if(dialog==null || dialog.getOwner() !=findFrame)
		{
			dialog=new JDialog(findFrame,false);//?
			dialog.add(this);
			dialog.getRootPane().setDefaultButton(findNext);
			dialog.setLocationRelativeTo(notepadFrame);
		
		}
		
		
		
		if(findTextField.getText().length()==0)
		{
			findNext.setEnabled(false);
			
		}
		else
		{
			findNext.setEnabled(true);
			
		}
		
		
		replaceAll.setVisible(false);
		replaceText.setVisible(false);
		replaceTextField.setVisible(false);
		replaceLabel.setVisible(false);

		if(isFindFrame)
		{
			
			dialog.setSize(460,180);
			dialog.setTitle("Find");
		}else {
			
			replaceText.setVisible(true);
			replaceAll.setVisible(true);
			
			replaceTextField.setVisible(true);
			replaceLabel.setVisible(true);
			
			dialog.setSize(450,200);
			
			dialog.setTitle("Find & Replace");
			
		}
		dialog.setVisible(true);
		dialog.setResizable(false);
		

		
		
	}
	
}
