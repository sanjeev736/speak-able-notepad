package notepade_s_plus;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GraphicsEnvironment;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.TextEvent;
import java.awt.event.TextListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class NotepadSPlusFontSelection extends JPanel{
	Font font;
	JList fontStyle,fontFace,fontSize;
	JDialog fontDialog;
	JButton ok,cancel;
	JTextArea area;
	JPanel heading,fontList,buttonPanel,textFieldPanel,mainPanel,boxPanel,headingWithBox;;
	String size[],faceName[],fontName[],s[];
	TextField fontFaceBox,fontStyleBox,fontSizeBox;
	boolean b;
	
	boolean check;
	
	public NotepadSPlusFontSelection(Font notepadFont) {
		textFieldBox();
		font=notepadFont;
		List<String> l=new ArrayList<String>();
		String s[]=GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
		for(String ss:s)
		{
			l.add(ss);
		}
		
		
		setFontList(l);
	
	
		
		
		
		
		 faceName=new String[]{"Regular","Bold","Italic","Bold & Italic"};
		fontStyle=new JList(faceName);
		fontStyle.setSelectedIndex(0);
		fontStyle.addListSelectionListener(new ListSelectionListener() {
			
			@Override
			public void valueChanged(ListSelectionEvent event) {
				area.setFont(createFont());
				fontStyleBox.setText((String)fontStyle.getSelectedValue());
			}
		});
		
		size=new String[30];
		for(int i=0;i<30;i++)
		{
			size[i]=10+i*2+"";
		}
		fontSize=new JList(size);
		fontSize.setSelectedIndex(0);
		fontSize.addListSelectionListener(new ListSelectionListener() {
			
			@Override
			public void valueChanged(ListSelectionEvent event) {
				area.setFont(createFont());
				fontSizeBox.setText((String)fontSize.getSelectedValue());
			}
		});
		
		
		fontFaceBox.addTextListener(new TextListener() {
			
			@Override
			public void textValueChanged(TextEvent event) {
			
			}
		});
		
		
		
		
		
		
		
		
		
		
		heading();
		fontList();
		
		
		headingWithBox=new JPanel();
		headingWithBox.setLayout(new GridLayout(2,1));
		headingWithBox.add(heading);
		headingWithBox.add(boxPanel);
		
		buttonPanel=new JPanel();
		buttonPanel.setLayout(new FlowLayout());
		buttonPanel.add(ok);
		buttonPanel.add(new JLabel("   "));
		buttonPanel.add(cancel);
		
		textFieldPanel();
		
		mainPanel =new JPanel();
		mainPanel.setLayout(new GridLayout(2,1));
		
		mainPanel.add(fontList);
		mainPanel.add(textFieldPanel);
//		mainPanel.add(buttonPanel);
	
		setLayout(new BorderLayout());
		add(headingWithBox,BorderLayout.NORTH);
		//add(heading,BorderLayout.NORTH);
//		add(d,BorderLayout.NORTH);
		add(mainPanel,BorderLayout.CENTER);
		add(buttonPanel,BorderLayout.SOUTH);
		add(new JLabel("  "),BorderLayout.EAST);
		add(new JLabel("  "),BorderLayout.WEST);
	
		area.setFont(font);
		area.append("\nA quick brown fox jumps over the lazy dog.");
		area.append("\n0123456789");
		area.append("\n~!@#$%^&*()_+|?><\n");

	}
	
	
	private void setFontList(List<String> a) {
		
		
		fontName=new String[a.size()];
		fontName=a.toArray(fontName);
		
		fontFace=new JList(fontName);

		fontFace.setSelectedIndex(0);
		fontFace.addListSelectionListener(new ListSelectionListener() {
			
			@Override
			public void valueChanged(ListSelectionEvent event) {
				area.setFont(createFont());
			fontFaceBox.setText((String)fontFace.getSelectedValue());
			}
		});
	
	}


		private void textFieldBox() {

		List<String> list=new ArrayList<String>();		
		fontFaceBox=new TextField();
		fontStyleBox=new TextField();
		fontSizeBox=new TextField();
		
		boxPanel=new JPanel();
		boxPanel.setLayout(new GridLayout(1,3));
		
		boxPanel.add(fontFaceBox);
		boxPanel.add(fontStyleBox);
		boxPanel.add(fontSizeBox);
		
		fontFaceBox.addTextListener(new TextListener() {
			
			@Override
			public void textValueChanged(TextEvent event) {
				// TODO Auto-generated method stub
				
			
String f[]=GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
for(int i=0;i<f.length;i++)
{
	
	if(f[i].startsWith("S")||f[i].startsWith("s"))
	{
		list.add(f[i]);
	}

}

				setFontList(list);
			}
		});

	}


		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	public void heading() {


		
		
		heading=new JPanel();
		heading.setLayout(new GridLayout(1, 3));
		heading.add(new JLabel("Font"),JLabel.CENTER);	
		heading.add(new JLabel("Font Style"),JLabel.CENTER);
		heading.add(new JLabel("Font Size"),JLabel.CENTER);
		
	}
	
	
	private void fontList() {
	
		fontList=new JPanel();
		fontList.setLayout(new GridLayout(1, 3));
		fontList.add(new JScrollPane(fontFace));
		fontList.add(new JScrollPane(fontStyle));
		fontList.add(new JScrollPane(fontSize));
		ok=new JButton("Ok");
		cancel=new JButton("Cancel");
	
		ok.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent ev) {

				check=true;
				
				font=createFont();
				fontDialog.setVisible(false);
				

			}
		});
		
		cancel.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent ev) {
				fontDialog.setVisible(false);
				
			}
		});
	
	
	
	
	
	
	
	
	
	
	
	}
	
	
	
	
	
private void textFieldPanel() {
	area=new  JTextArea(5,30);
	textFieldPanel=new JPanel();
	textFieldPanel.add(new JScrollPane(area));
	
	}
	
	
	
	
	
	
	
	public Font createFont() {

		Font font=this.font;
		int fontStyle=Font.PLAIN;
		int fontStyle1=this.fontStyle.getSelectedIndex();
		
		switch(fontStyle1)
		{

		case 0:
			fontStyle=Font.PLAIN;
			break;

		case 1:
			fontStyle=Font.BOLD;
			
			break;

		case 2:
			fontStyle=Font.ITALIC;

			break;

		case 3:
			fontStyle=Font.ITALIC+Font.BOLD;

			break;
		}
		
		int fontSize=Integer.parseInt((String)this.fontSize.getSelectedValue());
		String fontFace=(String)this.fontFace.getSelectedValue();
		font=new Font(fontFace,fontStyle,fontSize);
		
		return font;
	}
	
	public boolean showDialog(Component frameOfNotepadSPlus, String title)
	{
	check=false;

	Frame owner=null;
	if(frameOfNotepadSPlus instanceof Frame) 
		owner=(Frame)frameOfNotepadSPlus;
	else
		owner=(Frame)SwingUtilities.getAncestorOfClass(Frame.class,frameOfNotepadSPlus);
	if(fontDialog==null || fontDialog.getOwner()!=owner)
	{
	fontDialog=new JDialog(owner,true);
	fontDialog.add(this);
	fontDialog.getRootPane().setDefaultButton(ok);
	fontDialog.setSize(400,325);
//	fontDialog.setLocationByPlatform(true);
	fontDialog.setLocationRelativeTo(frameOfNotepadSPlus);

	fontDialog.setVisible(true);
	}

	fontDialog.setTitle(title);
	//System.out.println(dialog.getWidth()+" "+dialog.getHeight());
//	System.out.println(check);
	return check;
	}
}
