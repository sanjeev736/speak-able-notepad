package notepade_s_plus;

import java.io.File;

public interface NotepadSPlusActionName {

	 void newFile();
	 void openFile();
	 boolean saveFile(File temp);
	 boolean saveAsFile();

	 
	
}
