package notepade_s_plus;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;

public class ItemsCreation {

	static JMenu createMenu(String menuName,int menuKey,JMenuBar menuBar)
	{
		JMenu menu=new JMenu(menuName);
		
		menu.setMnemonic(menuKey);
		 
		menuBar.add(menu);
		
		
		return menu;
		
		
	}
		
	static JMenuItem createMenuItems(String menuItemName,int menuItemKey,JMenu menuName,int menuItem_ctrl_Key,ActionListener actionListener  )//use of ctrl button
	{
		JMenuItem menuItem=new JMenuItem(menuItemName,menuItemKey);
		menuItem.setAccelerator(KeyStroke.getKeyStroke(menuItem_ctrl_Key,ActionEvent.CTRL_MASK));
		menuItem.addActionListener(actionListener);
		
		menuName.add(menuItem);
		
		
		
		return menuItem;
		
	}
	static JMenuItem createMenuItems(String menuItemName,int menuItemKey,JMenu menuName,ActionListener actionListener  )
	{
		JMenuItem menuItem=new JMenuItem(menuItemName,menuItemKey);
		menuItem.addActionListener(actionListener);
		
		menuName.add(menuItem);
		
		
		
		return menuItem;
		
	}
	static JCheckBoxMenuItem createCheckBoxMenuItem(String checkBoxMenuItemName,int CheckBoxMenuItemKey,JMenu menuName,ActionListener actionListener  )
	{

	JCheckBoxMenuItem checkBoxMenuItem=new JCheckBoxMenuItem(checkBoxMenuItemName);  
	checkBoxMenuItem.setMnemonic(CheckBoxMenuItemKey);  
	checkBoxMenuItem.addActionListener(actionListener);  
	checkBoxMenuItem.setSelected(false);  
	menuName.add(checkBoxMenuItem);  
	  
	return checkBoxMenuItem;  

		
	}
	
	
}
