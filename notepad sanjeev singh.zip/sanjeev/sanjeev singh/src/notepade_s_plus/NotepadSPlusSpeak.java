package notepade_s_plus;

import com.sun.speech.freetts.Voice;
import com.sun.speech.freetts.VoiceManager;

public class NotepadSPlusSpeak  {
 
	
	public NotepadSPlusSpeak() {



}
	
	private static final String VOICENAME = "kevin16";                                        
	void mySpeak(String read)
	{
	Voice voice;
	VoiceManager vm = VoiceManager.getInstance();
	voice = vm.getVoice(VOICENAME);
	voice.allocate();
	try{
	voice.speak(read);
	}catch(Exception e){}
	}

	
	
	
}
/*

use freets 1.2.2 lib jar files


*/