package notepade_s_plus;

import java.io.File;

import javax.swing.filechooser.FileFilter;

public class NotepadeSPlusFilter extends FileFilter {

	String description,extension;
	
	public NotepadeSPlusFilter() {
	setDescription(null);
	setExtention(null);
	}
	
	public NotepadeSPlusFilter(String ext,String des) {
	
	
	setDescription(des);
	setExtention(ext);
	
	}
	
	
	
	private void setExtention(String ext) {

		if(ext==null)
		{
		
			extension=null;
			return;
		}
		else
		{
			extension=new String(ext).toLowerCase();
		}
		if(!ext.startsWith("."))
		{
			extension="."+extension;
		}
		
	}
	private void setDescription(String des) {
		
		if(des==null)
		{
			description=new String("All File(*.*)");
		}
		else {
			description=des;
		}

	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@Override
	public boolean accept(File f) {
		final String filename=f.getName();

		if(	f.isDirectory() || 
			extension==null || 
			filename.toUpperCase()
			.endsWith(extension.toUpperCase()))
			return true;
		return false;
	}

	@Override
	public String getDescription() {
		return description;
	}

}
