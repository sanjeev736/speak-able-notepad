package notepade_s_plus;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.Date;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;
import javax.swing.text.BadLocationException;
// singleton class
public class NotepadSPlusMenu  implements MenuNames,ActionListener {
  
	
	static NotepadSPlus notepad;
	static NotepadSPlusFontSelection fontSelection;
	static NotepadSPlusActions actions;
	static NotepadSPlusFindAction findAction;
	static JMenuBar menuBar;
	static JMenu fileMenu,editMenu,formatMenu,viewMenu,helpMenu,colorMenu,speakMenu;
	static int line_Number;
	static JMenuItem  undoItem,redoItem,cutItem,copyItem,pasteItem,deleteItem,
	gotoItem,replaceItem,selectAllItem,colorItem,findNextItem;	
	
	public NotepadSPlusMenu(NotepadSPlus notepad) {
		//findAction=NotepadSPlusFindAction.obj(notepad);
		actions=NotepadSPlusActions.obj(notepad);
		this.notepad=notepad;
		
		
		createMenu(notepad);
	}
	
static NotepadSPlusMenu obj(NotepadSPlus notepad)
{
	
	
	NotepadSPlusMenu notepadSPlusMenu=new  NotepadSPlusMenu(notepad);
	return notepadSPlusMenu;
}

	
	private void createMenu(JFrame notepad) {

		menuBar=new JMenuBar();

		fileMenu=ItemsCreation.createMenu(FILE,KeyEvent.VK_F,menuBar);  
		editMenu=ItemsCreation.createMenu(EDIT,KeyEvent.VK_E,menuBar);  
	
        formatMenu=ItemsCreation.createMenu(FORMAT,KeyEvent.VK_O,menuBar);  
		viewMenu=ItemsCreation.createMenu(VIEW,KeyEvent.VK_V,menuBar);  
		speakMenu=ItemsCreation.createMenu(SPEAK,KeyEvent.VK_S,menuBar);
		helpMenu=ItemsCreation.createMenu(HELP,KeyEvent.VK_H,menuBar);  
		colorMenu=ItemsCreation.createMenu(COLOR,KeyEvent.VK_C,menuBar);

		
		/********************************************//*FILE_MENU*/
		
		ItemsCreation.createMenuItems(NEWFILE,KeyEvent.VK_N, fileMenu, KeyEvent.VK_N,this);	
		ItemsCreation.createMenuItems(OPEN,KeyEvent.VK_O, fileMenu, KeyEvent.VK_O,this);	
		ItemsCreation.createMenuItems(SAVE,KeyEvent.VK_S, fileMenu, KeyEvent.VK_S,this);	
		ItemsCreation.createMenuItems(SAVE_AS,KeyEvent.VK_A, fileMenu, this);	
		fileMenu.addSeparator();
		//createMenuItems(PAGE_SETUP,KeyEvent.VK_T, fileMenu,this);	
		ItemsCreation.createMenuItems(PRINT,KeyEvent.VK_P, fileMenu, KeyEvent.VK_P,this);	
		ItemsCreation.createMenuItems(EXIT,KeyEvent.VK_X, fileMenu,this);	
		
		/********************************************************/	
		
		
		/********************************************//*EDIT_MENU*/

		editMenu.addSeparator();
		
		
		cutItem=ItemsCreation.createMenuItems(CUT,KeyEvent.VK_U, editMenu, KeyEvent.VK_X,this);	
		copyItem=ItemsCreation.createMenuItems(COPY,KeyEvent.VK_C, editMenu, KeyEvent.VK_C,this);	
		pasteItem=ItemsCreation.createMenuItems(PASTE,KeyEvent.VK_P, editMenu, KeyEvent.VK_V,this);	
		deleteItem=ItemsCreation.createMenuItems(DELETE,KeyEvent.VK_D, editMenu,this);	
		editMenu.addSeparator();
		
		findNextItem=ItemsCreation.createMenuItems(FIND,KeyEvent.VK_X, editMenu,KeyEvent.VK_F,this);	
		replaceItem=ItemsCreation.createMenuItems(REPLACE,KeyEvent.VK_L, editMenu, KeyEvent.VK_R,this);	
		gotoItem=ItemsCreation.createMenuItems(GO_TO,KeyEvent.VK_F, editMenu, KeyEvent.VK_G,this);	
		editMenu.addSeparator();
		selectAllItem=ItemsCreation.createMenuItems(SELECT_ALL,KeyEvent.VK_A, editMenu, KeyEvent.VK_A,this);	
		ItemsCreation.createMenuItems(TIME_DATE,KeyEvent.VK_T, editMenu, KeyEvent.VK_T,this);	
		
		/********************************************************/	
		
		/**formate menu********************************************************/	
		
		ItemsCreation.createCheckBoxMenuItem(WORD_WRAP,KeyEvent.VK_W,formatMenu,this);	
		ItemsCreation.createMenuItems(FONT,KeyEvent.VK_F, formatMenu,this);	
		formatMenu.addSeparator();
		
		
		formatMenu.add(colorMenu);
		
		ItemsCreation.createMenuItems(FOREGROUND,KeyEvent.VK_F, colorMenu,this);
		
		ItemsCreation.createMenuItems(BACKGROUND,KeyEvent.VK_B, colorMenu,this);
		
		/********************************************************/	
		/**viwe menu******************************************************/	
		
		ItemsCreation.createCheckBoxMenuItem(STATUS_BAR,KeyEvent.VK_S, viewMenu,this).setSelected(true);
	
		 ThemeSelection.selectThemes(viewMenu,notepad);  
		
		/********************************************************/	

		 /**Speak MENU******************************************************/			
		 
			ItemsCreation.createMenuItems(READER,KeyEvent.VK_R,speakMenu,this);	
		
		
		 
		 
		 /****************************************************************/			

		 
		 
		 
		/**HELP MENU******************************************************/			
		
		 ItemsCreation.createMenuItems(ABOUT_NOTEPAD,KeyEvent.VK_N, helpMenu,this);
		 ItemsCreation.createMenuItems(ABOUT_CREATOR,KeyEvent.VK_C, helpMenu,this);

		
		
		/********************************************************/			
	
	
	
	
	
		 MenuListener editMenuListener=new MenuListener()  
		 {  
		    public void menuSelected(MenuEvent evvvv)  
		     {  
		   
				if(NotepadSPlus.textArea.getText().length()==0)
 				{
 					
					
					findNextItem.setEnabled(false);
					replaceItem.setEnabled(false);
					selectAllItem.setEnabled(false);
					gotoItem.setEnabled(false);
					
					
					
 				}else
 				{


					findNextItem.setEnabled(true);
					replaceItem.setEnabled(true);
					selectAllItem.setEnabled(true);
					gotoItem.setEnabled(true);
					
 				}
				
				if(NotepadSPlus.textArea.getSelectionStart()==NotepadSPlus.textArea.getSelectionEnd())
 				{
 					
					cutItem.setEnabled(false);
					copyItem.setEnabled(false);
					deleteItem.setEnabled(false);
 				}else
 				{
 					cutItem.setEnabled(true);
 					copyItem.setEnabled(true);
 					deleteItem.setEnabled(true);
 				}
 				
				
				
				
				
				
		 				}
		 				
		 				@Override
		 				public void menuDeselected(MenuEvent arg0) {
		 				
		 				}
		 				
		 				@Override
		 				public void menuCanceled(MenuEvent arg0) {
		 					
		 				}
		 			};
		 	

	
	editMenu.addMenuListener(editMenuListener);
	notepad.setJMenuBar(menuBar);
	}
	

	@Override
	public void actionPerformed(ActionEvent event) {
		
		String eventName=event.getActionCommand();
		switch(eventName)
		{
		case NEWFILE:
			actions.newFile();;
			break;
		case OPEN:
			actions.openFile();
			break;
		case SAVE:
			actions.saveMe();
			
			
			break;
		case SAVE_AS:
			actions.saveAsFile();
			break;	
		case PAGE_SETUP:
			break;
		case PRINT:
			JOptionPane.showMessageDialog(notepad," Printer Not Found! ","Print",JOptionPane.OK_OPTION);
			break;
		case EXIT:
			if(actions.saveConfirm())
			{
				System.exit(0);
			}
			break;
		case CUT :
			notepad.textArea.cut();
			break;
		case COPY:
			notepad.textArea.copy();
			break;
		case PASTE:
			notepad.textArea.paste();
			break;
		case DELETE:
			notepad.textArea.replaceSelection("");
			break;
		
		case FIND:
			findAction=	new NotepadSPlusFindAction(notepad);
			findAction.findDiaglog(notepad.textArea);
			findAction.showDialog(notepad,true);
			break;

		case REPLACE:
			findAction=	new NotepadSPlusFindAction(notepad);
			findAction.findDiaglog(notepad.textArea);
			findAction.showDialog(notepad,false);
			break;
		case GO_TO:
			try {
				line_Number=notepad.textArea.getLineOfOffset(notepad.textArea.getCaretPosition())+1;
		 String line=JOptionPane.showInputDialog(notepad,"Enter LineNumber",line_Number);
		if(line==null)
		{
			return;
		}
		 line_Number=Integer.parseInt(line);
		
			notepad.textArea.setCaretPosition(notepad.textArea.getLineStartOffset(line_Number-1));
		 
			} catch (BadLocationException e) {
			notepad.statusBar.setText(e.toString());
			}
		
		
			break;
		case SELECT_ALL:
			notepad.textArea.selectAll();
			
			break;
		case TIME_DATE:
			
			notepad.textArea.insert(new Date().toString(),notepad.textArea.getSelectionStart());
//			String timeAtFirstLine=new String(new Date().toString().concat("\n".concat(notepad.textArea.getText())));
//			notepad.textArea.setText("");;
//			notepad.textArea.insert(timeAtFirstLine,notepad.textArea.getSelectionStart());
			
			//notepad.textArea.insert(new Date().toString(),notepad.textArea.getCaretPosition());
			
			break;
		case WORD_WRAP:

			JCheckBoxMenuItem word_Wrap=(JCheckBoxMenuItem)event.getSource();
			notepad.textArea.setLineWrap(word_Wrap.isSelected());
			
			break;
		case FONT:
				

				fontSelection=new NotepadSPlusFontSelection(notepad.textArea.getFont());
							
			
			if(fontSelection.showDialog(notepad, "Set Font"))
			{
			
					notepad.textArea.setFont(fontSelection.createFont());
			}
			
			break;
		case FOREGROUND:
			actions.setNotepadTextColor();
			break;
		case BACKGROUND:
			actions.setNotepadBackgroundColor();
			break;
		case STATUS_BAR:
			
			JCheckBoxMenuItem status_Bar=(JCheckBoxMenuItem)event.getSource();  
			
			notepad.statusBar.setVisible(status_Bar.isSelected());
			
			break;
			
		case READER:
			NotepadSPlusSpeak speak=new NotepadSPlusSpeak();
			
			String read=notepad.textArea.getText();
			speak.mySpeak(read);
			break;
			
		
			
		case ABOUT_NOTEPAD:
			JOptionPane.showConfirmDialog(notepad, aboutNotepad,"Info",JOptionPane.OK_OPTION);
			break;

		case ABOUT_CREATOR:
		
			JOptionPane.showConfirmDialog(notepad, aboutCreator,"Info",JOptionPane.OK_OPTION);

			
			break;
			
			
			
			
			
			
		}
		
			
		
	}
	
	

	
	}

