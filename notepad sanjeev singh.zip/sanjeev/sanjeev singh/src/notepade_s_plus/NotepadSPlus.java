package notepade_s_plus;

import java.awt.BorderLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.event.CaretEvent;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;


public class NotepadSPlus extends Listner {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//JFrame notepad;
	static JLabel statusBar;
	static JTextArea textArea;
	NotepadSPlusMenu menu;
	NotepadSPlusActions actions;
	
	public NotepadSPlus() {
//		setVisible(true);
//		setLocation(100, 150);
		structure();
		actions=actions.obj(this);
		
DocumentListener documentListener=new DocumentListener() {
			
			@Override
			public void removeUpdate(DocumentEvent arg0) {
				// TODO Auto-generated method stub
				actions.saved=false;
			}
			
			@Override
			public void insertUpdate(DocumentEvent arg0) {
				// TODO Auto-generated method stub
				actions.saved=false;
			}
			
			@Override
			public void changedUpdate(DocumentEvent arg0) {
				// TODO Auto-generated method stub
				actions.saved=false;
			}
		};
		textArea.getDocument().addDocumentListener(documentListener);//?
		
		WindowListener W_listener=new WindowAdapter() {


public void windowClosing(WindowEvent we)  
{  
if(actions.saveConfirm())System.exit(0);  
}  
};  
this.addWindowListener(W_listener);
		
	};
	
	/*static NotepadSPlus obj()
	{
		NotepadSPlus notepadSPlus=new NotepadSPlus();
		return notepadSPlus;
	
	}
*/
	private void structure() {

		//menu=new NotepadSPlusMenu(this);
		
		menu.obj(this);
		
	 statusBar =new JLabel("$$                  L1 C1         ",JLabel.RIGHT);
		textArea=new JTextArea(30,60);
		//System.out.println(this.hashCode()+"----------"+statusBar.hashCode());
		 
		add(statusBar,BorderLayout.SOUTH);
		add(textArea);
		add(new JLabel("  "),BorderLayout.EAST);
		add(new JLabel("  "),BorderLayout.WEST);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		pack();
		textArea.addCaretListener(this);		
		
		add(new JScrollPane(textArea),BorderLayout.CENTER);

		pack();

	
		
	}


	@Override
	public void caretUpdate(CaretEvent caretEvent) {

		int position,lineNumber,columnNumber;
		try
		{
		position=textArea.getCaretPosition();
		
		lineNumber=textArea.getLineOfOffset(position);
		columnNumber=position-textArea.getLineStartOffset(lineNumber);
		
		//System.out.println(position+"\n"+lineNumber+"\n"+columnNumber+"\n********************");
		
		statusBar.setText("$$                  L"+(lineNumber+1)+" C"+(columnNumber+1)+"         ");


		}
		catch(Exception e)
		{
			System.out.println(e);
		}

		
	}

	public static void main(String[] args) {
		
	}
	
	
}


 
 
 
 
 
 