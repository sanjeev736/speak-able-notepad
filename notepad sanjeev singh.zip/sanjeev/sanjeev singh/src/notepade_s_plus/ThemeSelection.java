package notepade_s_plus;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JMenu;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

 class ThemeSelection
{

	 
	public static void selectThemes(JMenu J_Menu, Component J_frame) {
		String themeName[] ={"JavaFrame" ,"Machine","Old","Window","Classic"};

		final UIManager.LookAndFeelInfo[] themes=UIManager.getInstalledLookAndFeels();
		JRadioButtonMenuItem radioItems[]=new JRadioButtonMenuItem[themes.length];
		
		JMenu themeJMenu=new JMenu("Select Themes");
		themeJMenu.setMnemonic('T');
		ButtonGroup group=new ButtonGroup();
		
		for(int i=0;i<themes.length;i++)
		{
			radioItems[i]=new JRadioButtonMenuItem(themeName[i]);
			//radioItems[i]=new JRadioButtonMenuItem(themes[i].getName());
			radioItems[i].setMnemonic(themeName[i].charAt(0));
			//radioItems[i].setMnemonic(themes[i].getName().charAt(0));
			radioItems[i].addActionListener(new RadioItemsAction(themes[i].getClassName(),J_frame));
				
			group.add(radioItems[i]);
			themeJMenu.add(radioItems[i]);
		
		}

		radioItems[0].setSelected(true);
		J_Menu.add(themeJMenu);
		
	
	}
	
	static class RadioItemsAction implements ActionListener//double nested class
	{

		String themeName;
		Component J_frame;
		
		public RadioItemsAction(String themeName,
				Component j_frame) {

			this.themeName=themeName;
			this.J_frame=j_frame;
			
			
	}

		@Override
		public void actionPerformed(ActionEvent action) {
			try {
				UIManager.setLookAndFeel(themeName);
				SwingUtilities.updateComponentTreeUI(J_frame);

			
			} catch (Exception e) {
					e.printStackTrace();
			}
			
			
			
			
			
		}

		
		
	}
		}
