package notepade_s_plus;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.swing.JColorChooser;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

public class NotepadSPlusActions implements NotepadSPlusActionName {
 
	static NotepadSPlus notepad;
	static boolean saved,createNewFile;
	String fileName,applicationTitle="NotepadSPlus";
	String message;
	File fileRef;
	String statusText;
	JFileChooser chooser;
	JDialog textDialog,backgroundDialog;
	boolean opt;
	JColorChooser textColor,backgroundColor;
	
	
	public NotepadSPlusActions(NotepadSPlus notepad) {

		saved=createNewFile=true;
		
		
		this.notepad=notepad;
		
		
		


		
		
		
		
		fileName=new String("Untitled notepad");
		fileRef=new File(fileName);
		notepad.setTitle(fileName+" - "+applicationTitle);
		
		chooser=new JFileChooser();
		
		chooser.addChoosableFileFilter(new NotepadeSPlusFilter(".tst", "SText Files(*.tst)"));	//mine
		chooser.addChoosableFileFilter(new NotepadeSPlusFilter(".txt", "Text Files(*.txt)"));	
		chooser.addChoosableFileFilter(new NotepadeSPlusFilter(".java", "Java Files(*.java)"));	
		chooser.addChoosableFileFilter(new NotepadeSPlusFilter(".class", "Java Class File(*.class)"));
		
		
		chooser.setCurrentDirectory(new File("."));

	
		
		
		
	}
	public NotepadSPlusActions() {
		// TODO Auto-generated constructor stub
	}
	
	static NotepadSPlusActions obj(NotepadSPlus notepad)
	{
	NotepadSPlusActions actions=new NotepadSPlusActions(notepad);
		
		return actions;
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@Override
	public void newFile() {
		if(!saveConfirm())
		{
			return;
		}
		

notepad.textArea.setText("");
fileName=new String("Untitled notepad -");
fileRef=new File(fileName);

saved=true;
createNewFile=true;

fileName=fileName+" "+applicationTitle;
setNotepadTitle(fileName);

	}

	
	
	
	public boolean saveMe() {
		if(!createNewFile)
		{
		return saveFile(fileRef);
		}
		
		
		return saveAsFile();
	}
	
	

	public boolean saveConfirm() {

		
		message="Text In "+fileName+" Has Been Changed\n Do You Want To Save";
		
		if(!saved)
		{
			int x=JOptionPane.showConfirmDialog(notepad,message,applicationTitle,JOptionPane.YES_NO_CANCEL_OPTION);
			
			if(x==JOptionPane.CANCEL_OPTION )
			{
				return false;
				
			}
			
			if(x==JOptionPane.YES_OPTION && !saveAsFile())
			{
				return false;
			}
			
		}
		
		return true;
	}
	

	
	
	
	@Override
	public void openFile() {
		
		chooser.setDialogTitle("Open File...");
		chooser.setApproveButtonText("Open Me");
		chooser.setApproveButtonMnemonic(KeyEvent.VK_O);
		
		File temp;
		
		do
		{
			
			if(chooser.showOpenDialog(notepad)!=JFileChooser.APPROVE_OPTION)
			{
				return;
				
			}
			else {
				temp=chooser.getSelectedFile();
			if(temp.exists())
			{
				break;
			}else {
				
				JOptionPane.showMessageDialog(notepad, "<html>"+temp.getName()+"<br>doesn't exist</html>","Error in Opening",JOptionPane.INFORMATION_MESSAGE);
				
			}
			
			
			}
			
			
			
		}while(true);
		
		notepad.textArea.setText("");
		
		if(!openAndWrite(temp))
			{
			fileName="(untitled)\t"+applicationTitle;
			setNotepadTitle(fileName);
						
			}
		else
		{
			fileName=fileName+"     "+applicationTitle;
			setNotepadTitle(fileName);
			
		}
		if(!temp.canWrite())
		{
			createNewFile=true;
		}
		notepad.statusBar.setText(statusText);

		
		
		
		
		
		
		
		
		
		
		
	}

		
	@Override
	public boolean saveFile(File temp) {
		
		FileWriter writer=null;
		try {
			 writer=new  FileWriter(temp);

			 writer.write(notepad.textArea.getText());
			 
			 
		}catch (Exception e) {
			
			//e.printStackTrace();
			updateInFile(temp,false);			
			return false;

		}
		finally{
			
			try{writer.close();}
			catch(IOException excp){}
		}
		updateInFile(temp,true);
		

		
		
		
		
		
		
		
		
		
		return true;
	}
	
	@Override
	public boolean saveAsFile() {


		File temp=null;
		chooser.setDialogTitle("Save Your File Here...");
		chooser.setApproveButtonText("Save Me");
		chooser.setApproveButtonMnemonic(KeyEvent.VK_S);
		
		do
		{
			if(chooser.showSaveDialog(notepad)!=JFileChooser.APPROVE_OPTION)
			{
				return false;		
			}
			temp=chooser.getSelectedFile();
			
			if(!temp.exists())
			{
				break;
			}
			
			if(temp.exists())
			{
				message="<html>File Already Exist!<br>"+temp.getPath()+"<br>Do You Want Replace It ?</html>";
				if((JOptionPane.showConfirmDialog(notepad,message,"SaveAs",JOptionPane.YES_NO_OPTION))==JOptionPane.YES_OPTION)
						{
					break;
						}
						
			
			}
			
		}while(true);
		fileName=temp.getName();
		setNotepadTitle(fileName);
		return saveFile(temp);
	}


	
	
	
	private boolean openAndWrite(File fileName) {
		BufferedReader reader=null;
	//	BufferedInputStream
		try {
		
			reader=new BufferedReader(new InputStreamReader(new FileInputStream(fileName)));
			String text="";
			while(true)/////////////?
			{
				text=reader.readLine();
				if(text==null)//ask que?.equals(null)
				{
					break;
				}
				
				notepad.textArea.append(text+"\n");
				
			}
		
		
		} catch (Exception e) {
			
			//e.printStackTrace();
			updateInFile(fileName,false);			
			return false;

		}
		finally{
			
			try{reader.close();}
			catch(IOException excp){}
		}
		updateInFile(fileName,true);
		notepad.textArea.setCaretPosition(0);
		return true;


		
	}
	
	
	
	
	
	
	private void updateInFile(File f_Name, boolean saved) {
		


		if(saved)
		{
			
			//System.out.println("2="+notepad.hashCode()+"----------"+notepad.statusBar.hashCode()); 
			this.saved=saved;
			this.fileName=new String(f_Name.getName());
			
			if(!f_Name.canWrite())
			{
			this.fileName+="(Read Only)";	
			createNewFile=true;	//?
			}
			fileRef=f_Name;
			
			statusText="File from "+f_Name.getPath()+" Saved/Opened Successfully";
			
			createNewFile=false;		//?	
			
			
		}
		else {
			statusText="File from "+f_Name.getPath()+" Failed To Open";
		
		
		}
		
	}
	
	private void setNotepadTitle(String f_Name)
	{
		notepad.setTitle(fileName);	
	}
	
	public void setNotepadBackgroundColor() 
	{
		if(backgroundColor==null)
		{
	backgroundColor=new JColorChooser();
	if(backgroundDialog==null)
	{
		backgroundDialog=JColorChooser.createDialog(notepad,NotepadSPlusMenu.BACKGROUND , false	, backgroundColor, new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent act) {
				
			notepad.textArea.setBackground(backgroundColor.getColor());
			}
		}	, null);
		
		
		
	}
		}
		backgroundDialog.setVisible(true);
	}///////////?
	
	public void setNotepadTextColor() 
	{
		
		if(textColor==null)
		{
		textColor=new JColorChooser();		
	if(textDialog==null)
	{
		textDialog=JColorChooser.createDialog(notepad, NotepadSPlusMenu.FOREGROUND, true, textColor, new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent act) {
				notepad.textArea.setForeground(textColor.getColor());

				
			}
		}, null);
		textDialog.setVisible(true);
		
	}
		}
		
		
		}////////////?

		
	
	
	
	
	
	
	

	
	
}
