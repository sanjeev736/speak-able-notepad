package notepade_s_plus;

import javax.swing.JFrame;
import javax.swing.event.CaretListener;

public abstract class Listner  extends  JFrame implements CaretListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
